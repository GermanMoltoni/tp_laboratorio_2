﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibreriaFinal
{
    public delegate void delegadoEvento(object obj,EventArgs e);
    public class Galpon<T>
    {
        public List<T> lista;
        private int _cantidad;
        public event delegadoEvento EsImpar;
        public Galpon()
        {
            this.lista = new List<T>();
        }
        public int Cantidad
        {
            set 
            {
                if (value == 0)
                {
                    throw new ArgumentException("No se puede asignar 0 a cantidad");
                }
                else if (value.EsPar())
                {
                    this._cantidad = value;
                }
                else if (value.EsImpar())
                {
                    this.EsImpar(value, new EventArgs());
                    this._cantidad = value;
                }
            }
            
        }

    }
}
