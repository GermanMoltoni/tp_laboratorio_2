﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibreriaFinal
{
    public class Canasta <T>
    {
        private List<T> _plantas;
        private int _capacidad;
        
        private Canasta()
        {
            this._plantas = new List<T>();
        }
        public Canasta(int cap)
            : this()
        {
            this._capacidad = cap;
        }
        public static Canasta<T> operator +(Canasta<T> ca1,ReinoVegetal t1)
        {
            if (!object.Equals(t1,null)&&!object.Equals(ca1,null))
            {
                if (typeof(T) == t1.GetType())
                {
                    if (ca1._plantas.Count < ca1._capacidad)
                    {
                        T aux = (T)Convert.ChangeType(t1, typeof(T));
                        ca1._plantas.Add(aux);
                    }
                    else
                    {
                        throw new NoAgregaException("Capacidad al Limite");
                    }
                    
                }
                else
                {
                    throw new NoAgregaException("El elemento es del tipo" + t1.GetType() + ". Se esperaba " + typeof(T) + ".");
                }
            }
            return ca1;
        }
        public override string ToString()
        {
            StringBuilder ret = new StringBuilder();
            foreach (T aux in this._plantas)
            {
                if (aux is LibreriaFinal.Fruta)
                {
                    Fruta aux2 = (Fruta)Convert.ChangeType(aux, typeof(Fruta));
                    ret.AppendLine(aux2.MostrarDatos());
                }
                else if (aux is LibreriaFinal.Verdura)
                {
                    Verdura aux2 = (Verdura)Convert.ChangeType(aux, typeof(Verdura));
                    ret.AppendLine(aux2.MostrarDatos());
                }
                else if (aux is LibreriaFinal.Carnibora)
                {
                    Carnibora aux2 = (Carnibora)Convert.ChangeType(aux, typeof(Carnibora));
                    ret.AppendLine(aux2.MostrarDatos());
                }
            }
            return ret.ToString();

        }
    }
}
