﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibreriaFinal
{
    public class Fruta : ReinoVegetal,IVegetales
    {
        private ConsoleColor _color;
        public Fruta(float valor, Gusto gusto,ConsoleColor color) :base(valor,gusto)
        {
            this._color = color;
        }
        public ConsoleColor Color { get { return this._color;} }
        public static implicit operator string(Fruta f1)
        {
            return (string)((ReinoVegetal)f1)+"\nColor: " + f1._color;
        }

        public string MostrarDatos()
        {
            return (string)this;
        }
    }
}
