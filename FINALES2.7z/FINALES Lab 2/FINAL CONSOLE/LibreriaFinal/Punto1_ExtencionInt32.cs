﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibreriaFinal
{
    public static class Punto1_ExtencionInt32
    {
        public static bool EsPar(this Int32 n)
        {
            bool flag = false;
            if (n % 2 == 0)
            {
                flag = true;
            }
            return flag;
        }
        public static bool EsImpar(this Int32 n)
        {
            return !(EsPar(n));
        }
    }
}
