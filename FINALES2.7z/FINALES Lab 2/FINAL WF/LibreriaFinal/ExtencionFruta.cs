﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibreriaFinal
{
    public static class ExtencionFruta
    {
        public static string MostrarElemento(this Fruta f)
        {
            return (string)f;
        }
    }
}
