﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibreriaFinal
{
    public class ExceptionPunto6 :Exception
    {
        public ExceptionPunto6() : base("PUNTO 6 LOGRADO") { }
    }
}
