﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibreriaFinal
{
    //[Serializable]
    public class Verdura : ReinoVegetal,IVegetales
    {
        public enum TipoVerdura
        {
            Semilla,
            Raíz, 
            Tubérculo, 
            Bulbo, 
            Tallo, 
            Hoja, 
            Inflorescencia, 
            Rizoma
        }
        private TipoVerdura _tipo;
        public Verdura();
        public Verdura(float valor, Gusto gusto,TipoVerdura tipo) :base(valor,gusto)
        {
            this._tipo = tipo;
        }
        public TipoVerdura Tipo { get { return this._tipo; } }
        public static implicit operator string(Verdura v1)
        {
            return (string)((ReinoVegetal)v1)+"\nTipo: " + v1._tipo;
        }
        public string MostrarDatos()
        {
            return (string)this;
        }
    }
}
