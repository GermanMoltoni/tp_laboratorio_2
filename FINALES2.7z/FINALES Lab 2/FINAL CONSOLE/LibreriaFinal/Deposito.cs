﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibreriaFinal
{
    public class Deposito
    {
        #region Fields
        public List<Producto> productos;
        #endregion
        #region Builders
        public Deposito()
        {
            this.productos = new List<Producto>();
        }
        #endregion
        #region Methods
        public static List<Producto> operator +(Deposito lista1, Deposito lista2)
        {
            List<Producto> aux = lista2.productos;
            bool flag = false;
            if (lista1 != null && lista2 != null)
            {
                for (int i = 0; i < lista1.productos.Count; i++)
                {
                    for (int j = 0; j < lista2.productos.Count; j++)
                    {
                        if (lista1.productos[i].nombre == lista2.productos[j].nombre)
                        {
                            aux[j].stock = lista1.productos[i].stock + lista2.productos[j].stock;
                            flag = true;
                            break;
                        }
                    }
                    if (flag == false)
                    {
                        aux.Add(lista1.productos[i]);
                    }
                    flag = true;
                }
            }
            return aux;
        }
        #endregion
    }
}
