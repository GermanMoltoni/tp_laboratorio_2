﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Archivos;

namespace LibreriaFinal
{
    public delegate void GustosDistintosDelegado(ReinoVegetal o1,ReinoVegetal o2);
    [Serializable]
    public abstract class ReinoVegetal
    {
        
        public enum Gusto 
        {
            Dulce,
            Salado,
            Toxica
        }
        protected float _valor;
        protected Gusto _gusto;
        private static Random _calcularValor;
        public static event GustosDistintosDelegado GustosDistintos;
        #region paraSerializar
        public ReinoVegetal();
        public float valor { get {return this._valor ;} set {this._valor = value ;} }
        public Gusto gusto { get { return this._gusto; } set { this._gusto = value; } }
        #endregion
        static ReinoVegetal()
        {
            ReinoVegetal._calcularValor= new Random();
        }
        public ReinoVegetal(float valor, Gusto gusto)
        {
            this._valor = valor;
            this._gusto = gusto;
        }
        public ReinoVegetal(Gusto gusto)
        {
            this._gusto = gusto;
            this._valor = ReinoVegetal._calcularValor.Next(1, 100);
        }
        public static bool operator ==(ReinoVegetal rv1,ReinoVegetal rv2)
        {
            bool flag = false;
            if (!object.Equals(rv1,null)&&!object.Equals(rv2,null))
            {
                if (rv1.GetType() == rv2.GetType())
                {
                    if (rv1._gusto != rv2._gusto)
                    {
                        ReinoVegetal.GustosDistintos(rv1,rv2);
                    }
                    else
                    {
                        flag = true;
                    }
                }
                //else
                //{
                //    if (rv1._gusto != rv2._gusto)
                //    {
                //        ReinoVegetal.GustosDistintos(rv1, rv2);
                //    }
                //}
            }
            return flag;
        }
        public static bool operator !=(ReinoVegetal rv1, ReinoVegetal rv2)
        {
            return !(rv1 == rv2);
        }
        public static explicit operator string(ReinoVegetal rv1)
        {
            return "Valor: " + rv1._valor + "\nGusto: " + rv1._gusto;
        }

        public static bool Guardar(List<ReinoVegetal> lista)
        {
            
            try
            {
                Xml<ReinoVegetal> xml = new Xml<ReinoVegetal>();
                foreach (ReinoVegetal item in lista)
                {
                    xml.Guardar(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\ListaGustosDistintos.Xml", item);
                }
                return true;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
    }
}
