﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibreriaFinal
{
    public class Carnibora :ReinoVegetal,IVegetales
    {
        public enum Captura 
        {
            Pinzas,
            Pelos, 
            Caída, 
            Mecánicas,
            Combinada
        }

        private Captura _tipo;
        private int _tamanio;
        public Carnibora(float valor, Gusto gusto, Captura tipo)
            : base(valor, gusto)
        {
            this._tipo = tipo;
        }
        public Carnibora(float valor, Gusto gusto,Captura tipo,int tamanio) :this(valor,gusto,tipo)
        {
            this._tamanio = tamanio;
        }
        public Captura Tipo { get { return this._tipo; } }
        public int Tamanio { get { return this._tamanio; } }
        public static implicit operator string(Carnibora c1)
        {
            return (string)((ReinoVegetal)c1)+"\nTipo: " + c1._tipo + "\nTamanio: " + c1._tamanio;
        }
        public string MostrarDatos()
        {
            return (string)this;
        }
    }
}
