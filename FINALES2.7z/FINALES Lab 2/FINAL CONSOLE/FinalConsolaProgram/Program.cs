﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using LibreriaFinal;

namespace FinalConsolaProgram
{
    class Program
    {
        static void Main(string[] args)
        {
            // PUNTO 2 TEST
            Stack<double> nums = new Stack<double>();
            nums.Push(1);
            nums.Push(2);
            nums.Push(3);
            Stack<double> nums2 = new Stack<double>();
            nums2.Push(1);
            nums2.Push(2);
            nums2.Push(3);
            Console.WriteLine(nums2.Pop().ToString());
            Console.WriteLine(nums2.Pop().ToString());
            Console.WriteLine(nums2.Pop().ToString());
            nums = Program.OrdenarAlReves(nums);

            Console.WriteLine(nums.Pop().ToString());
            Console.WriteLine(nums.Pop().ToString());
            Console.WriteLine(nums.Pop().ToString());
            Console.ReadLine();
            // PUNTO 3
            Deposito dep1 = new Deposito();
            Deposito dep2 = new Deposito();
            Producto prod1 = new Producto("Chupetin", 2);
            Producto prod2 = new Producto("Caramelo", 6);
            Producto prod3 = new Producto("Chupetin", 8);
            Producto prod4 = new Producto("BebidaPepsi", 5);
            dep1.productos.Add(prod1);
            dep1.productos.Add(prod2);
            dep2.productos.Add(prod3);
            dep2.productos.Add(prod4);
            //Punto 5
            try
            {
                Galpon<Producto> Galpon = new Galpon<Producto>();
                Galpon.lista.Add(prod1);
                Galpon.Cantidad = 0;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.ReadLine();
            }
            //PUNTO 6
            try
            {
                Program.Punto6Static();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        //PUNTO 2 FUNCION
        public static Stack<double> OrdenarAlReves(Stack<double> pila)
        {
            Stack<double> aux = new Stack<double>();
            int lenght = pila.Count;
            for (int i = 0; i < lenght; i++)
            {
                aux.Push(pila.Pop());
            }
            return aux;
        }
        //PUNTO 6 METODOS
        public static void Punto6Static()
        {
            try
            {
                Program prog = new Program();
                prog.Punto6();
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        public void Punto6()
        {
            throw new ExceptionPunto6();
        }
        #region Manejador de Evento
        private static void GuardarLog(object obj,EventArgs e)
        {
            try
            {
                using (StreamWriter archivoTxT = File.AppendText(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "//log.txt"))
                {
                    archivoTxT.WriteLine(DateTime.Now+"---> "+obj);
                }
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }
        #endregion
    }
}
